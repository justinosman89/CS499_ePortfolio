package com.personal.inventoryapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class NotificationSystemActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification); // Ensure this layout file exists in res/layout
    }
}
